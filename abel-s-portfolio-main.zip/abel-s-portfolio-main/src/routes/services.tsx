import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Abel Geremew" },
      {
        name: "description",
        content:
          "Services offered by Abel Geremew: website development, application development, web maintenance and application support.",
      },
      { property: "og:title", content: "Services — Abel Geremew" },
      {
        property: "og:description",
        content:
          "Services offered by Abel Geremew: website development, application development, web maintenance and application support.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Services,
});

const services = [
  {
    t: "Website Development",
    d: "Fast, responsive, modern websites built from scratch.",
  },
  {
    t: "Application Development",
    d: "Full-stack web applications, from planning to launch.",
  },
  {
    t: "Web Maintenance",
    d: "Updates, performance tuning, security and uptime for existing websites.",
  },
  {
    t: "Application Support",
    d: "Troubleshooting, bug fixing and production support for running applications.",
  },
];

function Services() {
  return (
    <section className="mx-auto max-w-5xl px-6 pt-20 pb-24">
      <h1 className="text-3xl font-bold md:text-4xl">What I do</h1>
      <div className="mt-10 grid gap-6 sm:grid-cols-2">
        {services.map((s) => (
          <div key={s.t} className="rounded-xl border border-border bg-card p-6">
            <h2 className="text-lg font-semibold">{s.t}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
