import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Abel Geremew" },
      {
        name: "description",
        content:
          "Contact Abel Geremew for websites, applications, maintenance or support work.",
      },
      { property: "og:title", content: "Contact — Abel Geremew" },
      {
        property: "og:description",
        content:
          "Contact Abel Geremew for websites, applications, maintenance or support work.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Contact,
});

function Contact() {
  return (
    <section className="mx-auto max-w-3xl px-6 pt-24 pb-28 text-center">
      <h1 className="text-3xl font-bold md:text-4xl">Let's work together</h1>
      <p className="mt-4 text-muted-foreground">
        Need a website, an application, or maintenance and support for one you
        already have? I'm available — send me an email.
      </p>
      <a
        href="mailto:abelgeremew16192405@gmail.com"
        className="mt-8 inline-block rounded-lg bg-primary px-8 py-4 font-medium text-primary-foreground transition hover:bg-primary/90"
      >
        abelgeremew16192405@gmail.com
      </a>
    </section>
  );
}
