import { createFileRoute, Link } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Abel Geremew — Web & Application Developer" },
      {
        name: "description",
        content:
          "Portfolio of Abel Geremew: website and application developer, web maintenance developer and application support engineer.",
      },
      { property: "og:title", content: "Abel Geremew — Web & Application Developer" },
      {
        property: "og:description",
        content:
          "Websites, applications, maintenance and support work by Abel Geremew.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <section className="mx-auto max-w-5xl px-6 pt-24 pb-20">
      <div className="grid items-center gap-12 md:grid-cols-2">
        <div>
          <p className="text-sm text-muted-foreground">Hi, I'm Abel Geremew</p>
          <h1 className="mt-3 text-4xl font-bold leading-tight md:text-5xl">
            I build websites & applications that work.
          </h1>
          <p className="mt-6 max-w-md text-muted-foreground">
            Website and application developer, web maintenance developer and
            application support engineer.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/projects"
              className="rounded-lg bg-primary px-6 py-3 font-medium text-primary-foreground transition hover:bg-primary/90"
            >
              View my work
            </Link>
            <Link
              to="/contact"
              className="rounded-lg border border-border px-6 py-3 font-medium transition hover:bg-secondary"
            >
              Contact me
            </Link>
          </div>
        </div>
        <img
          src={hero}
          alt="Developer workspace with code on screen"
          width={1600}
          height={900}
          className="rounded-2xl border border-border"
        />
      </div>
    </section>
  );
}
