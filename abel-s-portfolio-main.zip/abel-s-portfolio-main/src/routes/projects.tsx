import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Projects — Abel Geremew" },
      {
        name: "description",
        content:
          "Websites and applications Abel Geremew has built, plus his maintenance and support work.",
      },
      { property: "og:title", content: "Projects — Abel Geremew" },
      {
        property: "og:description",
        content:
          "Websites and applications Abel Geremew has built, plus his maintenance and support work.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Projects,
});

const groups = [
  {
    title: "Websites",
    items: [
      {
        name: "Melaku Clinic",
        d: "Clinic website with doctor profiles and appointment booking, designed for a client.",
      },
      {
        name: "Bruk Cafe",
        d: "Café website with menu, gallery and online ordering, designed for a client.",
      },
    ],
  },
  {
    title: "Application",
    items: [
      {
        name: "TaskFlow",
        d: "Team task manager with boards, deadlines and live updates — an application I built myself.",
      },
    ],
  },
  {
    title: "Web Maintenance",
    items: [
      {
        name: "Musk Shop",
        d: "Kept a retail store website up to date, fast and reliably online.",
      },
      {
        name: "Sunrise Hotel",
        d: "Handled ongoing updates and fixes for a hotel booking website.",
      },
    ],
  },
  {
    title: "Application Maintenance",
    items: [
      {
        name: "InventoryPro",
        d: "Maintained a warehouse inventory application, keeping it stable and current.",
      },
    ],
  },
  {
    title: "Application Support",
    items: [
      {
        name: "Abacus Teach",
        d: "Provided troubleshooting and day-to-day support for an application.",
      },
    ],
  },
];

function Projects() {
  return (
    <section className="mx-auto max-w-5xl px-6 pt-20 pb-24">
      <h1 className="text-3xl font-bold md:text-4xl">My work</h1>
      <div className="mt-10 space-y-12">
        {groups.map((group) => (
          <div key={group.title}>
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              {group.title}
            </h2>
            <div className="mt-4 grid gap-6 md:grid-cols-2">
              {group.items.map((p) => (
                <article key={p.name} className="rounded-xl border border-border bg-card p-6">
                  <h3 className="text-lg font-semibold">{p.name}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{p.d}</p>
                </article>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
