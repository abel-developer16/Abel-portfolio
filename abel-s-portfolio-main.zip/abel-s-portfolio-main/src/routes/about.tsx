import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Abel Geremew" },
      {
        name: "description",
        content:
          "About Abel Geremew, a website and application developer, and the technologies he works with.",
      },
      { property: "og:title", content: "About — Abel Geremew" },
      {
        property: "og:description",
        content:
          "About Abel Geremew, a website and application developer, and the technologies he works with.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: About,
});

const skills = ["HTML", "CSS", "JavaScript", "C++", "Python", "Node.js", "Next.js"];

function About() {
  return (
    <section className="mx-auto max-w-5xl px-6 pt-20 pb-24">
      <h1 className="text-3xl font-bold md:text-4xl">About me</h1>
      <p className="mt-6 max-w-2xl text-muted-foreground">
        I'm a website and application developer. I turn ideas into reliable
        digital products — from building a site or an app from scratch to
        keeping existing ones running smoothly through maintenance and support.
      </p>
      <h2 className="mt-12 text-xl font-semibold">Technologies I've learned and use</h2>
      <div className="mt-6 flex flex-wrap gap-3">
        {skills.map((s) => (
          <span
            key={s}
            className="rounded-full border border-border bg-card px-5 py-2 font-mono text-sm"
          >
            {s}
          </span>
        ))}
      </div>
    </section>
  );
}
